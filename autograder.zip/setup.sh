python3 -m pip install pygame
python3 -m pip install numpy
